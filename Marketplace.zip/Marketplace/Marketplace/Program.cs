﻿using System;
using Marketplace.Manager;

namespace Marketplace
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("MarketPlace Start!");
            new MarketManager().StartMarket();
        }
    }
}
