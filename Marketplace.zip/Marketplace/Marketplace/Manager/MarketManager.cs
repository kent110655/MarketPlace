﻿using System;
using Marketplace.Services;

namespace Marketplace.Manager
{
    public class MarketManager
    {
        private readonly ProductServices ProductService = new ProductServices();
        private readonly UserServices UserService = new UserServices();
        private readonly DBservices DB = new DBservices();
        
        public void StartMarket()
        {
            DB.Build_DB();      //創建Database MarketPlace
            //DB.Build_Table();   //創建Table Users,Products.
            while (true)
            {
                Console.Write("# ");
                var input = Console.ReadLine();
                string[] cmd = input.Split(' ');    //CREATE_LISTING user1 'Phone model 8' 'Black color, brand new' 1000 'Electronics'
                switch (cmd[0])
                {
                    case "REGISTER":
                        cmd = Handle_string(cmd, 2);
                        if (cmd.Length != 2)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }    
                        UserService.Register(cmd[1]);
                        break;
                    case "CREATE_LISTING":
                        cmd = Handle_string(cmd, 6);
                        if (cmd.Length != 6)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }
                        ProductService.Create_Listing(cmd[1], cmd[2], cmd[3], int.Parse(cmd[4]), cmd[5]);
                        break;
                    case "DELETE_LISTING":
                        cmd = Handle_string(cmd, 3);
                        if (cmd.Length != 3)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }
                        ProductService.Delete_Listing(cmd[1], int.Parse(cmd[2]));
                        break;
                    case "GET_LISTING":
                        cmd = Handle_string(cmd, 3);
                        if (cmd.Length != 3)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }
                        ProductService.Get_Listing(cmd[1], int.Parse(cmd[2]));
                        break;
                    case "GET_CATEGORY":
                        cmd = Handle_string(cmd, 5);
                        if (cmd.Length != 5)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }
                        ProductService.Get_Category(cmd[1], cmd[2], cmd[3], cmd[4]);
                        break;
                    case "GET_TOP_CATEGORY":
                        cmd = Handle_string(cmd, 2);
                        if (cmd.Length != 2)
                        {
                            Console.WriteLine("Input Incorrect!");
                            break;
                        }
                        ProductService.Get_Top_Category(cmd[1]);
                        break;
                    default:
                        Console.WriteLine("Input Incorrect!");
                        break;
                }
            }
            
        }

        //處理輸入格式問題（分出正確part，去除前後'）
        public string[] Handle_string(string[] cmd, int num)
        {
            string[] handle = new string[num];
            handle[0] = cmd[0];
            int cur = 1;
            for(int i = 1; i < cmd.Length; i++)
            {
                handle[cur] = cmd[i];
                if (cmd[i][0] == '\'')
                {
                    handle[cur] = cmd[i].Substring(1, cmd[i].Length - 1);
                    while (cmd[i][cmd[i].Length - 1] != '\'')
                    {
                        i++;
                        handle[cur] = handle[cur] + " " + cmd[i];
                    }
                    handle[cur] = handle[cur].Substring(0, handle[cur].Length - 1);
                }
                cur++;
            }
            return handle;
        }
    }
}
