﻿using System;
using System.Data.SqlClient;
//using MySql.Data.MySqlClient;
using System.Data.SQLite;

namespace Marketplace.Services
{
    public class DBservices
    {
        

        //創建Database MarketPlace //創建Table Users,Products
        public void Build_DB()
        {
            SQLiteConnection.CreateFile("MatketPlaceDB.db");
            SQLiteConnection connection = new SQLiteConnection();
            SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
            conbuild.DataSource = "MarketPlaceDB.db";
            connection.ConnectionString = conbuild.ToString();
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand(connection);
            string build_table = "DROP TABLE IF EXISTS Users;" + " DROP TABLE IF EXISTS Products;" +
                "CREATE TABLE IF NOT EXISTS Users(Username VARCHAR(255));" +
                "CREATE TABLE IF NOT EXISTS Products(" +
                "ListID INTEGER PRIMARY KEY," +
                "Title varchar(255)," +
                "Description varchar(255)," +
                "Price INTEGER," +
                "Username varchar(255)," +
                "Created_at datetime," +
                "Category varchar(255))" +
                "; ";
            cmd.CommandText = build_table;
            try
            {
                cmd.ExecuteNonQuery();
            }
            finally
            {
                cmd.Connection.Close();
            }
            
        }

        
        

        //刪除新增修改通用(1 parameter)
        public static bool Update<T>(string sql, string[] present, T[] para)
        {
            using (SQLiteConnection connection = new SQLiteConnection())
            {
                
                SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
                conbuild.DataSource = "MarketPlaceDB.db";
                connection.ConnectionString = conbuild.ToString();
                connection.Open();
                using (SQLiteCommand cmd = new SQLiteCommand(connection))
                {
                    cmd.CommandText = sql;
                    for (int i = 0; i < present.Length; i++)
                    {
                        cmd.Parameters.AddWithValue(present[i], para[i]);
                    }
                    try
                    {
                        return cmd.ExecuteNonQuery() > 0;
                    }
                    finally
                    {
                        cmd.Connection.Close();
                    }
                }
            }
            
        }

        //刪除新增修改通用(2 parameter)
        public static bool Update2<T, Q>(string sql, string[] present, T[] para, string[] present2, Q[] para2)
        {

            using (SQLiteConnection connection = new SQLiteConnection())
            {

                SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
                conbuild.DataSource = "MarketPlaceDB.db";
                connection.ConnectionString = conbuild.ToString();
                connection.Open();
                using (SQLiteCommand cmd = new SQLiteCommand(connection))
                {
                    cmd.CommandText = sql;
                    for (int i = 0; i < present.Length; i++)
                    {
                        cmd.Parameters.AddWithValue(present[i], para[i]);
                    }
                    for (int j = 0; j < present2.Length; j++)
                    {
                        cmd.Parameters.AddWithValue(present2[j], para2[j]);
                    }
                    try
                    {

                        return cmd.ExecuteNonQuery() > 0;
                    }
                    finally
                    {
                        cmd.Connection.Close();
                    }
                }
            }
        }


        //刪除新增修改通用(no parameter)
        public static bool Update_noPara(string sql)
        {
            using (SQLiteConnection connection = new SQLiteConnection())
            {

                SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
                conbuild.DataSource = "MarketPlaceDB.db";
                connection.ConnectionString = conbuild.ToString();
                connection.Open();
                using (SQLiteCommand cmd = new SQLiteCommand(connection))
                {
                    cmd.CommandText = sql;
                    try
                    {
                        return cmd.ExecuteNonQuery() > 0;
                    }
                    finally
                    {
                        cmd.Connection.Close();
                    }
                }
            }
            
        }

        //返回第一行第一列結果(1 parameter)
        public static object SelectForScalar<T>(string sql, string[] present, T[] para)
        {
            using (SQLiteConnection connection = new SQLiteConnection())
            {

                SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
                conbuild.DataSource = "MarketPlaceDB.db";
                connection.ConnectionString = conbuild.ToString();
                connection.Open();
                using (SQLiteCommand cmd = new SQLiteCommand(connection))
                {
                    cmd.CommandText = sql;
                    for (int i = 0; i < present.Length; i++)
                    {
                        cmd.Parameters.AddWithValue(present[i], para[i]);
                    }
                    try
                    {
                        return cmd.ExecuteScalar();
                    }
                    finally
                    {
                        cmd.Connection.Close();
                    }
                }
            }
            
        }



        //返回第一行第一列結果(no parameter)
        public static object SelectForScalar_noPara(string sql)
        {
            using (SQLiteConnection connection = new SQLiteConnection())
            {

                SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
                conbuild.DataSource = "MarketPlaceDB.db";
                connection.ConnectionString = conbuild.ToString();
                connection.Open();
                using (SQLiteCommand cmd = new SQLiteCommand(connection))
                {
                    cmd.CommandText = sql;
                    try
                    {
                        return cmd.ExecuteScalar();
                    }
                    finally
                    {
                        cmd.Connection.Close();
                    }
                }
            }
            
        }
        

        //返回DataReader(1 parameter)
        public static SQLiteDataReader SelectForReader<T>(string sql, string[] present, T[] para)
        {

            SQLiteConnection connection = new SQLiteConnection();
            SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
            conbuild.DataSource = "MarketPlaceDB.db";
            connection.ConnectionString = conbuild.ToString();
            connection.Open();
            SQLiteCommand cmd = new SQLiteCommand(connection);
            cmd.CommandText = sql;
            for (int i = 0; i < present.Length; i++)
            {
                cmd.Parameters.AddWithValue(present[i], para[i]);
            }
            try
            {
                return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
                cmd.Connection.Close();
                return null;
            }
        }

        //返回DataReader(no parameter)
        public static SQLiteDataReader SelectForReader_noPara(string sql)
        {
            SQLiteConnection connection = new SQLiteConnection();
            SQLiteConnectionStringBuilder conbuild = new SQLiteConnectionStringBuilder();
            conbuild.DataSource = "MarketPlaceDB.db";
            connection.ConnectionString = conbuild.ToString();
            connection.Open();

            SQLiteCommand cmd = new SQLiteCommand(connection);
            cmd.CommandText = sql;
            try
            {
                return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            }
            catch (Exception e)
            {
                cmd.Connection.Close();
                return null;
            }
        }
        
    }
}
