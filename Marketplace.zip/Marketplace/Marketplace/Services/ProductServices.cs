﻿using System;
using Marketplace.Services;

namespace Marketplace.Services
{
    public class ProductServices
    {
        static int ID = 100000;

        //驗證Username是否存在
        public bool Login(string username)
        {
            var sql_user = $"SELECT COUNT(0) FROM Users WHERE Username = @username";
            string[] present = new string[1];
            string[] para = new string[1];
            present[0] = "@username";
            para[0] = username;
            return (long)DBservices.SelectForScalar(sql_user, present, para) != 0;
        }

        //添加一筆清單內容
        public long Create_Listing(string username, string title, string description,  int price, string category)
        {
            //var listid = RandomID();  //隨機取不重複的ID
            var listid = RegularID();   //從100000開始照順序往後取ID
            if (Login(username))  //username存在
            {
                var sql_insert = $"INSERT INTO Products(ListID, Title, Description, Price, Username, Created_at, Category) VALUES(@listid, @title, @description, @price, @username, datetime('now', 'localtime'), @category);";

                string[] present1 = new string[4];
                string[] para1 = new string[4];
                present1[0] = "@title";
                para1[0] = title;
                present1[1] = "@description";
                para1[1] = description;
                present1[2] = "@username";
                para1[2] = username;
                present1[3] = "@category";
                para1[3] = category;

                string[] present2 = new string[4];
                int[] para2 = new int[4];
                present2[0] = "@listid";
                para2[0] = listid;
                present2[1] = "@price";
                para2[1] = price;

                DBservices.Update2(sql_insert, present1, para1, present2, para2);
                Console.WriteLine(listid);
                return listid;
            }
            else    //username不存在
            {
                Console.WriteLine("Error - unknown user");
                return -1;
            }
        }

        public int RegularID()
        {
            while(true)
            {
                ID++;
                var sql = $"SELECT COUNT(0) FROM Products WHERE ListID=@ID";
                string[] present = new string[1];
                int[] para = new int[1];
                present[0] = "@ID";
                para[0] = ID;
                if ((long)DBservices.SelectForScalar(sql, present, para) == 0)
                {
                    return ID;
                }
            }
        }

        //隨機取一個ID
        public int RandomID()
        {
            Random r = new Random();
            while (true)
            {
                int id = r.Next(100, 100000);
                var sql = $"SELECT COUNT(0) FROM Products WHERE ListID=@id";
                string[] present = new string[1];
                int[] para = new int[1];
                present[0] = "@id";
                para[0] = id;
                if ((long)DBservices.SelectForScalar(sql, present, para) == 0)
                {
                    return id;
                }
            }
        }

        //查詢並顯示一筆清單資料
        public void Get_Listing(string username, int listid)
        {
            if(!Login(username))  //username無效
            {
                Console.WriteLine("Error - unknown user");
                return;
            }
            var sql_getlisting = $"SELECT Title, Description, Price, Created_at, Category, Username FROM Products WHERE ListID= @listid";

            string[] present = new string[1];
            int[] para = new int[1];
            present[0] = "@listid";
            para[0] = listid;

            var list = DBservices.SelectForReader(sql_getlisting, present, para);
            if(list.Read()) //找到符合list
            {
                Console.WriteLine("{0}|{1}|{2}|{3}|{4}|{5}", list.GetString(0), list.GetString(1), list.GetInt32(2), list.GetDateTime(3), list.GetString(4), list.GetString(5));
            }
            else    //沒找到符合list
            {
                Console.WriteLine("Error - not found");
            }
            list.Close();
        }

        //刪除一筆清單資料
        public void Delete_Listing(string username, int listid)
        {
            var sql_id = $"SELECT COUNT(0) FROM Products WHERE ListID = @listid";
            string[] present1 = new string[1];
            int[] para1 = new int[1];
            present1[0] = "@listid";
            para1[0] = listid;
            if ((long)DBservices.SelectForScalar(sql_id, present1, para1) == 0)  //list id不存在
            {
                Console.WriteLine("Error - listing does not exist");
            }
            else    //list id存在
            {
                var sql_username = $"SELECT Username FROM Products WHERE ListID = @listid";
                string[] present2 = new string[1];
                int[] para2 = new int[1];
                present2[0] = "@listid";
                para2[0] = listid;
                var name = (string)DBservices.SelectForScalar(sql_username, present2, para2);
                if(name != username)    //username不符
                {
                    Console.WriteLine("Error - listing owner mismatch");
                }
                else //username相符
                {
                    var sql_delete = $"DELETE FROM Products WHERE ListID = @listid";
                    string[] present3 = new string[1];
                    int[] para3 = new int[1];
                    present3[0] = "@listid";
                    para3[0] = listid;
                    DBservices.Update(sql_delete, present3, para3);
                    Console.WriteLine("Success");
                }
            }
        }

        //顯示特定種類的清單資料
        public void Get_Category(string username, string category, string sort_type, string sort_rule)
        {
            if (!Login(username))  //username無效
            {
                Console.WriteLine("Error - unknown user");
                return;
            }
            var sql_exist = $"SELECT COUNT(0) FROM Products WHERE Category = @category";

            string[] present = new string[1];
            string[] para = new string[1];
            present[0] = "@category";
            para[0] = category;

            if ((long)DBservices.SelectForScalar(sql_exist, present, para) == 0) //category不存在
            {
                Console.WriteLine("Error - category not found");
            }
            else    //category存在
            {
                var type = (sort_type == "sort_price") ? "Price" : "Created_at";    //若輸入異常會默認時間排序
                var rule = (sort_rule == "asc") ? "ASC" : "DESC";   //若輸入異常會默認由大到小排序
                var sql_category = $"SELECT Title, Description, Price, Created_at FROM Products WHERE Category = @category2 ORDER BY " + type + " " + rule + " ;";

                string[] present2 = new string[3];
                string[] para2 = new string[3];
                present2[0] = "@category2";
                para2[0] = category;

                var list_category = DBservices.SelectForReader(sql_category, present2, para2);
                while(list_category.Read())
                {
                    var title = list_category.GetString(0);
                    var description = list_category.GetString(1);
                    var price = list_category.GetInt32(2);
                    var time = list_category.GetDateTime(3);
                    Console.WriteLine("{0}|{1}|{2}|{3}", title, description, price, time);
                }
                list_category.Close();
            }
        }

        //顯示最多的種類
        public void Get_Top_Category(string username)
        {
            if (!Login(username))  //username無效
            {
                Console.WriteLine("Error - unknown user");
                return;
            }
            var sql_count = $"SELECT Category ,COUNT(*) AS Count FROM Products GROUP BY Category ORDER BY Count DESC LIMIT 1;";
            var list = DBservices.SelectForReader_noPara(sql_count);
            if(list.Read())
            {
                Console.WriteLine("{0}",list.GetString(0));
            }
            list.Close();
        }
    }
}
