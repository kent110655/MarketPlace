﻿using System;
using Marketplace.Services;

namespace Marketplace.Services
{
    public class UserServices
    {
        //註冊Username
        public bool Register(string username)
        {
            var sql = $"SELECT COUNT(*) FROM Users WHERE Username = @username";
            string[] present = new string[1];
            string[] para = new string[1];
            present[0] = "@username";
            para[0] = username;
            if ((long)DBservices.SelectForScalar(sql, present, para) == 0)   //沒有註冊過的Username
            {
                Console.WriteLine("Success");
                return AddUser(username);
            }
            else    //Username已註冊過
            {
                Console.WriteLine("Error - user already existing");
                return false;
            }
        }

        public bool AddUser(string username)
        {
            var sql = $"INSERT INTO Users(Username) VALUES(@username);";
            string[] present = new string[1];
            string[] para = new string[1];
            present[0] = "@username";
            para[0] = username;
            return DBservices.Update(sql, present, para);
        }
    }
}
